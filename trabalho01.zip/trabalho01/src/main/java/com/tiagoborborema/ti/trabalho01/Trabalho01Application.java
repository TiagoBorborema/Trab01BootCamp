package com.tiagoborborema.ti.trabalho01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trabalho01Application {

	public static void main(String[] args) {
		SpringApplication.run(Trabalho01Application.class, args);
	}

}
